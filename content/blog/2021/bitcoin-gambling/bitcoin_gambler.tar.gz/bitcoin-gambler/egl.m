function fn_g = egl(mkt,res)     
%% Expected gain, conditioned on loss
%
% In: 
%   mkt = State struct with the following fields as Nx1 column vectors: 
%       a = current account value
%       s = sell amount
%       c = transaction cost ratio
%       v = current btc value
%       pc = crash probability
%       evc = expected crash value
%       evb = expected boom value
%       cap = btc price cap
%   res (optional) = resolution for numerical approximation to expectations
%
% Out: 
%   fn_g(ps) = expected gain conditioned on loss, given probability of sell

    if(nargin < 2), res = 1000; end;
   
    [~, fn_p_crash] = maxent_mean_bounds(0, mkt.v, mkt.evc);
    [~, fn_p_boom] = maxent_mean_bounds(mkt.v, mkt.cap, mkt.evb);
    fn_p = @(vv) mkt.pc*fn_p_crash(vv) + (1-mkt.pc)*fn_p_crash(vv);
    
    % E[Gain|Loss] = ps'*E[Gain|Loss, Hold]    + ps*E[Gain|Loss, Sell] 
    %              = ps'*E[Gain|Hold, Crash]   + ps*E[Gain|Sell, vnew < v*(a-cs)/(a-s)] 
    eglh = (mkt.evc/mkt.v-1)*mkt.a;

    egls = [];
    if(mkt.a-mkt.s == 0) % Sell entire account
        egls = (mkt.c-1)*mkt.a; 
    else
        tls = mkt.v*(mkt.a-mkt.c*mkt.s)/(mkt.a-mkt.s); % BTC price threshold for when selling creates a loss 
        tls = min(tls, mkt.cap);
        fn_gs = @(vv) (vv/mkt.v)*(mkt.a-mkt.s) + mkt.c*mkt.s - mkt.a; % Gain after a sell
        egls = expectation(fn_gs, fn_p, [0, tls, res]);
    end
    
    fn_g = @(ps) (1-ps)*eglh + ps*egls;
    return;
end
