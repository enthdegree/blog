function fn_pl = pl(mkt,res)     
%% Probability of a loss
%
% In: 
%   mkt = State struct with the following fields as Nx1 column vectors: 
%       a = current account value
%       s = sell amount
%       c = transaction cost ratio
%       v = current btc value
%       pc = crash probability
%       evc = expected crash value
%       evb = expected boom value
%       cap = btc price cap
%   res (optional) = resolution for numerical approximation to expectations
%
% Out: 
%   fn_pl(ps) = probability of loss as a function of sell probability

    if(nargin < 2), res = 1000; end;

    pls = [];
    if(mkt.a-mkt.s == 0) 
	pls = 1; % Selling whole account incurs transaction costs, a loss
    else
	tls = mkt.v*(mkt.a-mkt.c*mkt.s)/(mkt.a-mkt.s); % BTC price threshold for when selling creates a loss 
	tls = min(tls, mkt.cap);

	[~, fn_p_crash] = maxent_mean_bounds(0, mkt.v, mkt.evc);
	[~, fn_p_boom] = maxent_mean_bounds(mkt.v, mkt.cap, mkt.evb);
	fn_p = @(vv) mkt.pc*fn_p_crash(vv) + (1-mkt.pc)*fn_p_crash(vv);
 
	vx = linspace(0,mkt.cap, res);
	v_p = fn_p(vx); v_p = v_p/sum(v_p);
	pls = sum(v_p(vx <= tls));
    end
    fn_pl = @(ps) (1-ps)*mkt.pc + ps*pls;
    return;
end



