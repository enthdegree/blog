%% PRINT_STRAT.m Print a strategy found by GAMBLE.m
mkt.s = best_s;
fn_egl = egl(mkt);
fn_pl = pl(mkt);
fprintf('Strategy--------------------------------------\n');
fprintf('P(Sell):                         %-12.2f\n', best_ps);
fprintf('Sell amount:                     $%12.2f\n', best_s);
fprintf('E[Gain]:                         $%12.2f\n', best_eg);
fprintf('P(Loss):                         %-12.2f\n', fn_pl(best_ps));
fprintf('E[Gain|Loss]:                    $%12.2f\n', best_egl);
fprintf(' - E[Gain|Hold through a crash]: $%12.2f\n', fn_egl(0));
fprintf(' - E[Gain|Sell at weak price]:   $%12.2f\n', fn_egl(1));
fprintf('----------------------------------------------\n\n');
