%% GAMBLE.M How much to sell at a market precipice for a given tolerated expected loss 
% Model:
% - Future market either booms or crashes with some probability p_crash
% - In the event of a boom, market value follows the max-entropy distribution between the current value and a cap with a specified mean-boom value.
% - In the event of a crash, market value follows the max-entropy distribution between $0 and the current value with a specified mean-crash value.
% - Available actions are to hold, or to sell some amount and buy back.

pkg load optim;

% Parameters
res = 1000; 
mkt = struct;
    mkt.a = 6968; % Current account value
    mkt.minegl = -100; % Tolerable expected loss
    mkt.s = []; % Sell amount
    mkt.c = 0.97; % Transaction cost ratio
    mkt.v = 54105; % Current BTC value
    mkt.pc = 0.5; % Crash probability
    mkt.evc = 30000; % Expected crash value
    mkt.evb = 100000; % Expected boom value
    mkt.cap = 200000; % BTC price cap

run("print_params.m");
    
% Computation
v_ps = linspace(0, 1, 10);
v_s = linspace(0, mkt.a, res);
mtx_eg = nan(numel(v_s),numel(v_ps));
mtx_egl = nan(numel(v_s),numel(v_ps));

progbarlen = 10; progidx = -1; fprintf("Progress (to %i): ", progbarlen);
for idxs=1:numel(v_s)  
    prog = floor(progbarlen*idxs/numel(v_s)); 
    if(prog > progidx) fprintf("%i ", prog); progidx = prog; end

    mkt.s = v_s(idxs);
    fn_eg = eg(mkt);
    fn_egl = egl(mkt);
for idxps=1:numel(v_ps)
    mtx_eg(idxs, idxps) =  fn_eg(v_ps(idxps));
    mtx_egl(idxs, idxps) = fn_egl(v_ps(idxps));
end
end
fprintf("\n\n");

% Find best strategy
fprintf('Most lucrative strategy: \n');
[best_eg, idxbest] = max(mtx_eg(:));
best_egl = mtx_egl(idxbest);
[idxbest_s, idxbest_ps] = ind2sub(size(mtx_egl), idxbest);
best_ps = v_ps(idxbest_ps(1)); 
best_s = v_s(idxbest_s(1));
run("print_strat.m");
    
idxgood = find(mtx_egl > mkt.minegl); 
if(isempty(idxgood))
    fprintf('No strategy found with E[Gain|Loss] >= %.2f\n', mkt.minegl);
    fprintf('Most conservative strategy: \n');
    
    [best_eg, idxbest] = max(mtx_egl(:));
    best_egl = mtx_egl(idxbest);
    [idxbest_s, idxbest_ps] = ind2sub(size(mtx_egl), idxbest);
    best_ps = v_ps(idxbest_ps(1)); 
    best_s = v_s(idxbest_s(1));
    run("print_strat.m");
else
    fprintf('Best stragegy with E[Gain|Loss] >= %.2f:\n', mkt.minegl);
    
    [best_eg, iidxbest] = max(mtx_eg(idxgood));
    best_egl = mtx_egl(idxgood(iidxbest));
    [idxbest_s, idxbest_ps] = ind2sub(size(mtx_egl), idxgood(iidxbest));
    best_ps = v_ps(idxbest_ps(1)); 
    best_s = v_s(idxbest_s(1));
    run("print_strat.m");
end
