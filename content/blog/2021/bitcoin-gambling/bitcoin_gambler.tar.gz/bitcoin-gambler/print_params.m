%% PRINT_PARAMS.m Print parameters from GAMBLE.m
fprintf('Parameters------------------------------------\n');
fprintf('Current Balance:                 $%12.2f\n', mkt.a);
fprintf('Tolerable expected loss:         $%12.2f\n', mkt.minegl);
fprintf('Transaction cost ratio:          %-12.2f\n', mkt.c);
fprintf('Current BTC value:               $%12.2f\n', mkt.v);
fprintf('Crash probability:               %-12.2f\n', mkt.pc);
fprintf('Expected crash bottom:           $%12.2f\n', mkt.evc);
fprintf('Expected boom peak:              $%12.2f\n', mkt.evb);
fprintf('BTC price cap:                   $%12.2f\n', mkt.cap);
fprintf('----------------------------------------------\n\n');
