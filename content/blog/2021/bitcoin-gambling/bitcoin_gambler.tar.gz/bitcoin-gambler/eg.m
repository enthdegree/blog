function fn_g = eg(mkt)
%% Expected gain
%       
%   mkt = State struct with the following fields as Nx1 column vectors: 
%       a = current account value
%       s = sell amount
%       c = transaction cost ratio
%       v = current btc value
%       pc = crash probability
%       evc = expected crash value
%       evb = expected boom value
%       cap = btc price cap
%
% Out: fn_g(ps) = expected gain given sell probability

    evnew = mkt.pc*mkt.evc+(1-mkt.pc)*mkt.evb;
    fn_g = @(ps) (evnew/mkt.v)*(mkt.a-ps*mkt.s) + ps*mkt.c*mkt.s - mkt.a;
    return;
end
