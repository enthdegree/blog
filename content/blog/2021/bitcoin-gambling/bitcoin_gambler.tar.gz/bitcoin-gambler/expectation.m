function ve = expectation(fn_f, fn_p, vb)
%% Approximate expectation of a vector-valued function on the real line 
%
% In: 
%   fn_f = function, f([Nx1]) = ([NxM])
%   fn_p = probability distribution of X, must be sufficiently smooth
%   vb = [lower, upper, res (default=300)]
% Out: 
%   ve = approximate E[f(X)| X in vb]

    if(numel(vb) == 2), vb(3) = 300; end
    vx = linspace(vb(1), vb(2), vb(3))';
    
    vf = fn_f(vx);
    vp = fn_p(vx);
    vp = vp/sum(vp);
    
    n_out = size(vf,2);
    vp = repmat(vp, 1, n_out);
    ve = sum(vp.*vf);
    return;
end
