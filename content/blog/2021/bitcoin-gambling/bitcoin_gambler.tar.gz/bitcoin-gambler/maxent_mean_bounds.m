function [alpha, fn_p] = maxent_mean_bounds(a,b,mu)
%% Maximum entropy distribution given bounds and a mean
% In: 
%   a,b = min, max
%   mu = mean, inside the interval (a,b)
% Out:
%   alpha = constant specifying the pdf 
%   fn_p = function handle to pdf 
    
    if(isinf(a) && isinf(b))
        error('Trying to make a uniform distribution on the whole real line.');
    end
    
    if(mu == (a+b)/2) % Uniform
        alpha = 0;
        fn_p = @(x) (x >= a).*(x <= b)/(b-a);
        return;
    elseif(isinf(b)) % Tail at infty
        alpha = 1/(mu-a);
        fn_p = @(x) (x >= a).*-alpha*exp(alpha.*(x-a));
        return
    elseif(isinf(a)) % Tail at -infty
        alpha = 1/(b-mu);
        fn_p = @(x) (x <= b).* alpha*exp(alpha.*(x-b));
        return;
    else % Properly bounded
        
        guess = 1/(a+b); 
        is_skew_left = (mu < (a+b)/2);
        if(is_skew_left), guess = -1/(a+b); end
        
        fn_eq = @(alpha) (b*exp(alpha*b)-a*exp(alpha*a)) ./ (exp(alpha*b)-exp(alpha*a)) ...
            - 1./alpha - mu;
        alpha = lsqnonlin(fn_eq, guess, -100/(a+b), 100/(a+b));
        fn_p = @(x) (x >= a).*(x <= b).*alpha.*exp(alpha*x)/(exp(alpha*b)-exp(alpha*a));
        return;
    end
end
